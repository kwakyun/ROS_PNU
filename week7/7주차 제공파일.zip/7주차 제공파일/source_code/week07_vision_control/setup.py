from glob import glob
import os

from setuptools import find_packages, setup

package_name = "week07_vision_control"

setup(
    name=package_name,
    version="4.0.0",
    packages=find_packages(),
    data_files=[
        ("share/ament_index/resource_index/packages", ["resource/" + package_name]),
        ("share/" + package_name, ["package.xml"]),
        (os.path.join("share", package_name, "config"), glob("config/*.yaml")),
        (os.path.join("share", package_name, "launch"), glob("launch/*.launch.py")),
        (os.path.join("share", package_name, "models"), glob("models/*")),
    ],
    install_requires=["setuptools", "numpy", "PyYAML"],
    zip_safe=True,
    maintainer="Embedded Design Lab TA",
    maintainer_email="ta@example.com",
    description="Week 7 configurable cube1, cube2, and tip pixel detection",
    license="Apache-2.0",
    entry_points={
        "console_scripts": [
            "top_camera_publisher = week07_vision_control.top_camera_publisher:main",
            "yolo_object_detector = week07_vision_control.yolo_object_detector:main",
        ],
    },
)
