"""Launch the complete QuickRef-style joystick control chain on Jetson."""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    """Build the Jetson-only gamepad, IK, arm, FK, and EEF chain."""
    return LaunchDescription(
        [
            DeclareLaunchArgument(
                "device_id",
                default_value="0",
                description=(
                    "SDL joystick device ID reported by "
                    "joy_enumerate_devices"
                ),
            ),
            DeclareLaunchArgument(
                "start_joy",
                default_value="true",
                description="Start joy_node; false allows manual /joy tests",
            ),
            # TODO: joy 패키지의 joy_node를 등록하고 start_joy 조건과 device_id 파라미터를 연결하시오.
            Node(
                package=### TODO ###,
                executable=### TODO ###,
                name="joystick_pub_node",
                output="screen",
                condition=IfCondition(
                    LaunchConfiguration(### TODO ###)
                ),
                parameters=[
                    {
                        "device_id": LaunchConfiguration(
                            ### TODO ###
                        )
                    }
                ],
            ),
            # TODO: joystick_to_pose, arm_driver, ik_solver, fk_solver, ee_pose_listener 실행 노드를 등록하시오.
        ]
    )
